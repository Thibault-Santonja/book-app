create function trigger_set_timestamp() returns trigger
    language plpgsql
as
$$
BEGIN
  NEW.date_updated = now();
  RETURN NEW;
END;
$$;

alter function trigger_set_timestamp() owner to postgres;

